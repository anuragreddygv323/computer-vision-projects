__author__ = 'adrianrosebrock'

# import the necessary packages
from facedetector import FaceDetector